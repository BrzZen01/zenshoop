const express = require('express');
const path = require('path');
const db = require('../data/db');
const multer = require ('multer')
const Users = require('../data/Users');
const productManager = require('../data/producto');
const fs = require('fs')

const router = express.Router();
const users = new Users(db);
const product = new productManager(db);
const diskstorage = multer.diskStorage({
  destination: path.join(__dirname,'../images'),
  filename: (req, file, cb) => {
    cb(null, file.originalname )
  }
})

// Configurar la ruta estática para los componentes
router.use(express.static(path.join(__dirname, '..', 'public')));

router.post('/auth', async (req, res) => {
  const email = req.body.username;
  const clave = req.body.password;
  try {
    const user = await users.loginUser(email, clave);
    if (user.redirectPath === '/admin') {
      res.json({ success: true, redirectPath: '/menu' });
    } else if (user.redirectPath === '/user') {
      res.json({ success: true, redirectPath: '/usuarioMenu' });
    } else {
      res.status(401).json({ success: false, message: 'Usuario o contraseña incorrecta' });
    }
  } catch (err) {
    res.status(500).json({ success: false, message: 'Login failed due to an internal error: ' + err });
  }
});
// Ruta para renderizar la vista de productos
router.get('/productos', (req, res) => {
  db.query('SELECT * FROM producto', (err, results) => {
    console.log(results)
    if (err) {
      console.log(err);
      res.status(500).send('Error al obtener los productos');
    } else {
      res.json(results);
    }
  });
});

router.get('/usuarioMenu', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'pages', 'usuarioMenu.html'));
});


router.get('/menu', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'pages', 'administradorMenu.html'));
});

router.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '..', '..', 'index.html'));
});

router.get('/Login', (req, res) => {
  res.sendFile(path.join(__dirname, '..', '..', 'index.html'));
});

router.get('/Registro', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'pages', 'registroUsuarios.html'));
});

router.get('/registrarProducto', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'pages', 'registroProductos.html'));
});
const fileUpload = multer({
  storage: diskstorage
}).single('imagen')

router.post('/producto', fileUpload, async (req, res) => {
  const data = fs.readFileSync(path.join(__dirname, '..', 'images', req.file.originalname));
  const productData = {
    nombre: req.body.nombre,
    descripcion: req.body.descripcion,
    nameImg: req.file.originalname,
    valor: req.body.valor,
    img: data
  };

  try {
    await product.createProduct(productData);
    res.status(200).json({ success: true, message: 'Producto guardado con éxito' });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error al guardar el producto' });
  }
});
router.get('/roles', (req, res) => {
  db.query('SELECT * FROM roles', (err, results) => {
    if (err) {
      console.log(err);
      res.status(500).json({ error: 'Error al obtener los roles' });
    } else {
      res.json(results);
    }
  });
});

router.post('/crearUsuario', async (req, res) => {
  const userData = {
    nombreCompleto: req.body.nombreCompleto,
    email: req.body.email,
    direccion: req.body.direccion,
    telefono: req.body.telefono,
    clave: req.body.clave,
    idRoles: req.body.idRoles
  };

  try {
    const result = await users.createUser(userData);
    res.redirect(result === false ? '/registro?error=true' : '/?success=true');
  } catch (error) {
    console.error('Error al crear usuario:', error);
    res.redirect('/registro?error=true');
  }
});

router.post('/comprarProducto', async (req, res) => {
  try {
    const productosCarrito = req.body; // Array de objetos con idProducto y precio
    
    let total = 0;

    // Calcular el total de la factura
    productosCarrito.forEach(producto => {
      total += producto.precio;
    });

    // Insertar en la tabla factura
    db.query('INSERT INTO factura (total) VALUES (?)', [total], function (error, result, fields) {
      if (error) {
        console.error('Error al insertar en la tabla factura:', error);
        res.status(500).json({ success: false, message: 'Error al realizar la compra' });
        return;
      }

      const idFactura = result.insertId;

      // Preparar los valores para la inserción en detalle_factura
      const values = productosCarrito.map(producto => [idFactura, producto.idProducto, producto.precio]);

      // Insertar en la tabla detalle_factura
      db.query('INSERT INTO detalle_factura (iddetalle_factura, idProducto, precio) VALUES ?', [values], function (error, result, fields) {
        if (error) {
          console.error('Error al insertar en la tabla detalle_factura:', error);
          res.status(500).json({ success: false, message: 'Error al realizar la compra' });
          return;
        }
        
        // Solo enviar respuesta cuando se hayan completado todas las inserciones
        res.json({ success: true, message: 'Compra realizada con éxito' });
      });
    });
  } catch (error) {
    console.error('Error al realizar la compra:', error);
    res.status(500).json({ success: false, message: 'Error al realizar la compra' });
  }
});

module.exports = router;
