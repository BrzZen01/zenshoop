const express = require('express');
const router = express.Router();
const path = require('path');
const db = require('../data/db');

// Ruta para la página de registro de usuarios
router.get('/Registro', (req, res) => {
  res.sendFile(path.join(__dirname, 'pages', 'registroUsuarios.html'));
});

// Ruta para la página de inicio
router.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '..', '..', 'index.html'));
});




module.exports = router;
