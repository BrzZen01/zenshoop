// Función para obtener parámetros de la URL
function getUrlParameter(name) {
    name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
    var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
    var results = regex.exec(location.search);
    return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
};

// Función para mostrar la alerta de éxito o error
function showNotification() {
    var error = getUrlParameter('error');

if (error === 'true') {
        alert('El usuario ya existe');
    }
}

// Mostrar la notificación al cargar la página
window.onload = function () {
    showNotification();
};
