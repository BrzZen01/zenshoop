// Realizar una solicitud GET a la ruta '/roles' para obtener los roles
$.getJSON('/roles', function (data) {
    // Verificar si se recibieron datos válidos
    if (Array.isArray(data) && data.length > 0) {
        // Iterar sobre los datos recibidos y construir las opciones de la lista desplegable
        data.forEach(function (rol) {
            $('#roles-select').append('<option value="' + rol.idRoles + '">' + rol.NombreRol + '</option>');
        });
    } else {
        alert('No se recibieron datos de roles válidos del servidor.');
    }
}).fail(function () {
    alert('Error al obtener los roles. Inténtalo de nuevo.');
});
// Función para obtener parámetros de la URL
function getUrlParameter(name) {
    name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
    var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
    var results = regex.exec(location.search);
    return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
};

// Función para mostrar la alerta de éxito o error
function showNotification() {
    var success = getUrlParameter('success');
    var error = getUrlParameter('error');

    if (success === 'true') {
        alert('¡Usuario creado con éxito!');
    } else if (error === 'true') {
        alert('El usuario ya existe');
    }
}

// Mostrar la notificación al cargar la página
window.onload = function () {
    showNotification();
};
