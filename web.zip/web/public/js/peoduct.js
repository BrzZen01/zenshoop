const sendHandler = () =>{
    if(!file){
        alert('seleccione un archivo')
        return
    }
    const formdata = new FormData()
    formdata.append('image',file)
}