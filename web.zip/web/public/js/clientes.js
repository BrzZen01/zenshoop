// Manejo del carrito
let cart = [];

// Función para calcular el total del carrito
function calcularTotalCarrito() {
    let total = 0;
    cart.forEach(producto => {
        total += producto.Valor;
    });
    return total;
}

// Función para actualizar el botón del carrito
function updateCartButton() {
    const cartButton = document.querySelector('.cart-button');
    cartButton.textContent = cart.length;
}

// Función para actualizar el panel del carrito
function updateCartPanel() {
    const cartItemsContainer = document.querySelector('.cart-items');
    cartItemsContainer.innerHTML = '';

    cart.forEach((producto, index) => {
        const cartItem = document.createElement('div');
        cartItem.classList.add('cart-item');


        if (producto.img) {
            // Crear una nueva imagen
            const img = document.createElement('img');
            img.src = '../images/' + producto.nameImg; // O data:image/jpeg;base64, si la imagen es JPEG
            cartItem.appendChild(img);
        } else {
            // Si no hay imagen, mostrar una imagen de "no encontrada"
            const img = document.createElement('img');
            img.src = "../img/notFound.jpg";

            cartItem.appendChild(img);
        }


        const itemDetails = document.createElement('div');
        itemDetails.classList.add('item-details');

        const name = document.createElement('p');
        name.textContent = producto.NombreProducto;
        itemDetails.appendChild(name);

        const price = document.createElement('p');
        price.textContent = `Precio: $${producto.Valor.toLocaleString()}`;
        itemDetails.appendChild(price);

        cartItem.appendChild(itemDetails);

        const removeButton = document.createElement('button');
        removeButton.classList.add('remove-button'); // Agrega la clase para los estilos
        removeButton.textContent = 'Eliminar';
        removeButton.addEventListener('click', () => {
            cart.splice(index, 1);
            updateCartButton();
            updateCartPanel();
        });
        cartItem.appendChild(removeButton);

        cartItemsContainer.appendChild(cartItem);
    });

    // Mostrar el total del carrito
    const totalContainer = document.createElement('div');
    totalContainer.classList.add('total-container');
    totalContainer.textContent = `Total: $${calcularTotalCarrito().toLocaleString()}`;
    cartItemsContainer.appendChild(totalContainer);

    // Agregar botón de comprar
    const buyButton = document.createElement('button');
    buyButton.classList.add('buy-button'); // Agrega la clase para los estilos
    buyButton.textContent = 'Comprar';
    buyButton.addEventListener('click', () => {
        alert('Compra realizada');
        
        comprarProducto();
        cart = [];
        updateCartButton();
        updateCartPanel();
    });
    cartItemsContainer.appendChild(buyButton);
}

// Cuando el documento esté listo
document.addEventListener('DOMContentLoaded', function () {
    fetch('/productos')
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al obtener los productos');
            }
            return response.json();
        })
        .then(data => {
            data.forEach(producto => {
                const card = document.createElement('div');
                card.classList.add('product-card');

                const name = document.createElement('h3');
                name.textContent = producto.NombreProducto;
                card.appendChild(name);

                const description = document.createElement('p');
                description.textContent = producto.Descripcion;
                card.appendChild(description);

                const price = document.createElement('p');
                price.classList.add('price');
                price.innerHTML = `Precio: $${producto.Valor.toLocaleString()}`;
                card.appendChild(price);

                const shipping = document.createElement('p');
                shipping.classList.add('shipping');
                shipping.textContent = 'Envío gratis';
                card.appendChild(shipping);

                if (producto.img) {
                    // Crear una nueva imagen
                    const img = document.createElement('img');
                    console.log(producto.img)
                    // Establecer el atributo src con la ruta de la imagen base64
                    img.src = '../images/' + producto.nameImg; // O data:image/jpeg;base64, si la imagen es JPEG
                    
                    img.classList.add('product-image');
                    card.appendChild(img);
                } else {
                    // Si no hay imagen, mostrar una imagen de "no encontrada"
                    const img = document.createElement('img');
                    img.src = "../img/notFound.jpg";
                    
                    img.classList.add('product-image');
                    card.appendChild(img);
                }


                const addToCartBtn = document.createElement('button');
                addToCartBtn.classList.add('add-to-cart-btn');
                addToCartBtn.textContent = 'Añadir al carrito';
                addToCartBtn.addEventListener('click', () => {
                    cart.push(producto);
                    updateCartButton();
                    updateCartPanel();
                });
                card.appendChild(addToCartBtn);

                document.querySelector('.product-cards').appendChild(card);
            });
        })
        .catch(error => {
            console.error('Error al cargar los productos:', error);
            alert('Error al obtener los productos. Inténtalo de nuevo.');
        });

    document.querySelector('.cart-button').addEventListener('click', () => {
        const cartPanel = document.querySelector('.cart-panel');
        cartPanel.classList.toggle('open');
    });
});

// Función para realizar la compra
function comprarProducto() {
    const productosCarrito = cart.map(producto => ({ idProducto: producto.idProducto, precio: producto.Valor }));
    
    fetch('/comprarProducto', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(productosCarrito)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Error al realizar la compra');
        }
        cart = [];
        updateCartButton();
        updateCartPanel();
    })
    .catch(error => {
        console.error('Error al realizar la compra:', error);
        alert('Error al realizar la compra. Inténtalo de nuevo.');
    });
}
