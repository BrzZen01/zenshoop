class ProductManager {
    constructor(db) {
        this.db = db;
    }

    // Método para crear un nuevo producto
    async createProduct(productData) {
        return new Promise((resolve, reject) => {
            const sql = 'INSERT INTO producto (NombreProducto, descripcion, valor, img, nameImg) VALUES (?, ?, ?, ?, ?)';
            const { nombre, descripcion, valor,img, nameImg } = productData;
            this.db.query(sql, [nombre, descripcion, valor,img, nameImg ], (err, result) => {
                if (err) {
                    console.error('Error al crear producto:', err);
                    reject(err);
                } else {
                    resolve(result.insertId);
                }
            });
        });
    }

    // Método para obtener todos los productos
    async getAllProducts() {
        return new Promise((resolve, reject) => {
            const sql = 'SELECT * FROM producto';
            this.db.query(sql, (err, results) => {
                if (err) {
                    console.error('Error al obtener productos:', err);
                    reject(err);
                } else {
                    resolve(results);
                }
            });
        });
    }

    // Método para obtener un producto por su ID
    async getProductById(productId) {
        return new Promise((resolve, reject) => {
            const sql = 'SELECT * FROM producto WHERE idProducto = ?';
            this.db.query(sql, [productId], (err, results) => {
                if (err) {
                    console.error('Error al obtener producto por ID:', err);
                    reject(err);
                } else {
                    if (results.length === 0) {
                        resolve(null); // Producto no encontrado
                    } else {
                        resolve(results[0]);
                    }
                }
            });
        });
    }

    // Método para actualizar un producto
    async updateProduct(productId, productData) {
        return new Promise((resolve, reject) => {
            const sql = 'UPDATE producto SET NombreProducto = ?, descripcion = ?, valor = ? WHERE idProducto = ?';
            const { nombre, descripcion, valor } = productData;
            this.db.query(sql, [nombre, descripcion, valor, productId], (err, result) => {
                if (err) {
                    console.error('Error al actualizar producto:', err);
                    reject(err);
                } else {
                    if (result.affectedRows === 0) {
                        resolve(false); // Producto no encontrado
                    } else {
                        resolve(true); // Producto actualizado con éxito
                    }
                }
            });
        });
    }

    // Método para eliminar un producto
    async deleteProduct(productId) {
        return new Promise((resolve, reject) => {
            const sql = 'DELETE FROM producto WHERE idProducto = ?';
            this.db.query(sql, [productId], (err, result) => {
                if (err) {
                    console.error('Error al eliminar producto:', err);
                    reject(err);
                } else {
                    if (result.affectedRows === 0) {
                        resolve(false); // Producto no encontrado
                    } else {
                        resolve(true); // Producto eliminado con éxito
                    }
                }
            });
        });
    }
}

module.exports = ProductManager;
