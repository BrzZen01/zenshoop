const { use } = require("../routes/authRouter");

class UserManager {
    constructor(db) {
        this.db = db;
    }

    async createUser(userData) {
        return new Promise((resolve, reject) => {
            // Verificar si el correo electrónico ya está registrado
            this.db.query('SELECT COUNT(*) AS count FROM usuario WHERE email = ?', [userData.email], (err, result) => {
                if (err) {
                    console.error('Error al verificar el correo electrónico:', err);
                    reject(err);
                    return;
                }

                // Si count es mayor que 0, significa que el correo ya está en uso
                if (result[0].count > 0) {
                    resolve(false); // Retorna false si el correo electrónico ya está registrado
                    return;
                }

                // Definir la consulta SQL para insertar un nuevo usuario
                const sql = 'INSERT INTO usuario (NombreCompleto, email, Direccion, Telefono, Clave, Roles_idRoles) VALUES (?, ?, ?, ?, ?, ?)';

                // Extraer los datos del usuario de userData
                const { nombreCompleto, email, direccion, telefono, clave, idRoles } = userData;

                // Ejecutar la consulta para insertar el nuevo usuario
                this.db.query(sql, [nombreCompleto, email, direccion, telefono, clave, idRoles], (err, result) => {
                    if (err) {
                        console.error('Error al crear usuario:', err);
                        reject(err);
                    } else {
                        // Devolver el ID del usuario creado
                        resolve(result.insertId);
                    }
                });
            });
        });
    }

    async loginUser(email, clave) {
        return new Promise((resolve, reject) => {
            const sql = 'SELECT * FROM usuario WHERE email = ? AND Clave = ?';
            this.db.query(sql, [email, clave], (err, results) => {
                if (err) {
                    console.error('Error en el login del usuario:', err);
                    reject(err);
                } else if (results.length > 0) {
                    const user = results[0];
                    // Dependiendo del rol, definir la redirección
                    const redirectPath = user.Roles_idRoles === 1 ? '/admin' : '/user';
                    resolve({ success: true, redirectPath });
                } else {
                    resolve({ success: false,  message: 'Usuario o contraseña incorrecta' });
                }
            });
        });
    }
}

module.exports = UserManager;
