const mysql = require('mysql2/promise');

// Configurar la conexión a la base de datos
const db = mysql.createPool({
    host: 'localhost',
    user: 'root', // Cambia esto si tienes un usuario diferente
    password: 'root', // Cambia esto si tienes una contraseña
    database: 'tiendavirtual',
    port: 3306 // Puerto de MySQL, normalmente es 3306
});

// Comprobar la conexión a la base de datos
db.getConnection()
  .then(connection => {
    console.log('MySQL conectado...');
    connection.release();
  })
  .catch(error => {
    console.error('Error al conectar a MySQL:', error.message);
  });

module.exports = db;
