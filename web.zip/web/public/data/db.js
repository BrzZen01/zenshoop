const mysql = require('mysql2');

// Configurar la conexión a la base de datos
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root', // Cambia esto si tienes un usuario diferente
    password: 'root', // Cambia esto si tienes una contraseña
    database: 'tiendavirtual',
    port: 3306 // Puerto de MySQL, normalmente es 3306
});

// Conectar a la base de datos
db.connect(err => {
    if (err) {
        console.log(err);
    } else {
        console.log('MySQL conectado...');
    }
});

module.exports = db;
